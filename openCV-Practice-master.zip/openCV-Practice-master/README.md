# openCV-Practice

a opencv demo

you should import opencv2.framework yourself in http://opencv.org
