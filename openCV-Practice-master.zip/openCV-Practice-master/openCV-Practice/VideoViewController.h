//
//  VideoViewController.h
//  openCV-Practice
//
//  Created by Realank on 16/5/3.
//  Copyright © 2016年 realank. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VideoViewController : UIViewController

@end
